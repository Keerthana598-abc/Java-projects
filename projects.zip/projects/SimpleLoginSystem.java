import java.util.Scanner;

public class SimpleLoginSystem {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        // Hardcoded credentials
        String correctUsername = "admin";
        String correctPassword = "12345";

        // Ask user for input
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();

        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        // Validate login
        if (username.equals(correctUsername) && password.equals(correctPassword)) {
            System.out.println("✅ Login Successful! Welcome " + username);
        } else {
            System.out.println("❌ Login Failed! Invalid username or password.");
        }

        scanner.close();
    }
}
