
import java.util.Scanner;

class Student {
    String name;
    int[] marks = new int[3];
    double average;
    char grade;

    // Method to calculate average
    void calculateAverage() {
        int sum = 0;
        for (int i = 0; i < marks.length; i++) {
            sum += marks[i];
        }
        average = sum / 3.0;
    }

    // Method to calculate grade
    void calculateGrade() {
        if (average >= 75) {
            grade = 'A';
        } else if (average >= 60) {
            grade = 'B';
        } else if (average >= 50) {
            grade = 'C';
        } else {
            grade = 'F';
        }
    }

    // Method to display report
    void displayReport() {
        System.out.println("\n--- Student Report ---");
        System.out.println("Name: " + name);
        System.out.println("Marks:");
        for (int i = 0; i < marks.length; i++) {
            System.out.println("Subject " + (i + 1) + ": " + marks[i]);
        }
        System.out.println("Average: " + average);
        System.out.println("Grade: " + grade);
    }
}

public class StudentGradeSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Student s = new Student();

        System.out.print("Enter student name: ");
        s.name = sc.nextLine();

        for (int i = 0; i < 3; i++) {
            System.out.print("Enter marks for subject " + (i + 1) + ": ");
            s.marks[i] = sc.nextInt();
        }

        s.calculateAverage();
        s.calculateGrade();
        s.displayReport();

        sc.close();
    }
}
